from flask import Flask, render_template, redirect, request
from keyauth import api
import sys, time, platform, os, hashlib, json, webview, subprocess, sys, ctypes
from time import sleep
import datetime


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if is_admin():

    # Optional KeyAuth Start
    # def getchecksum():
    #     md5_hash = hashlib.md5()
    #     file = open(''.join(sys.argv), "rb")
    #     md5_hash.update(file.read())
    #     digest = md5_hash.hexdigest()
    #     return digest

    # keyauthapp = api(
    #     name = "",
    #     ownerid = "",
    #     secret = "",
    #     version = "",
    #     hash_to_check = getchecksum()
    # )

    # data = json.load(open('config.json'))
    # user = data['user']
    # password = data['passw']
    # Optional KeyAuth End

    title = 'Cyborg Cheats' # Window Title Here
    tname = 'Cyborg' # In Loader Name here
    discord = 'https://discord.gg/UgNhYaugB2' # Your Discord URL Here
    telegram = '' # Telegram here
    youtube = 'https://www.youtube.com/channel/UCK3q7ze2s_oi0PM__TGhqnQ' # YouTube Channel URL here
    cheat_location = ('7z.exe') # File Location here


    # optional KeyAuth Login
    # def answer():
    #     try:
    #         #ans = input(": ")
    #         if True:            
    #             keyauthapp.login(user, password)
    #         else:
    #             print("\nNot Valid Option")
    #             time.sleep(1)
    #             os.system('cls')
    #             answer()
    #     except KeyboardInterrupt:
    #         raw_input('Press Enter to exit!')
    #         os._exit(1)
    # answer()


    try:
        creation = datetime.datetime.fromtimestamp(int(keyauthapp.user_data.createdate))
        expiry = datetime.datetime.fromtimestamp(int(keyauthapp.user_data.expires))
        lastlogin = datetime.datetime.fromtimestamp(int(keyauthapp.user_data.lastlogin))
        username = keyauthapp.user_data.username
        subscription = keyauthapp.user_data.subscription

    except:
        creation = "KeyAuth Not Configured."
        expiry = "KeyAuth Not Configured."
        lastlogin = "KeyAuth Not Configured."
        username = "User"
        subscription = "Default"

    app = Flask(__name__ ,template_folder='templates')
    window = webview.create_window(title, app, fullscreen=True)
    @app.route("/")
    def index():
        return render_template("index.html", Name=username, tname=tname, discord=discord)

    @app.route("/apex-legends")
    def apex():
        return render_template("apex.html", tname=tname, discord=discord, telegram=telegram,youtube=youtube)

    @app.route("/profile")
    def profile():
        return render_template("profile.html",Name=username ,subscription=subscription, creation=creation, expiry=expiry, lastlogin=lastlogin)

    @app.route("/run_program")
    def run_program():
        if sys.platform == "win32":
            # Uncomment following comments to hide the main cheat from console / cmd
            # startupinfo = subprocess.STARTUPINFO()
            # startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            subprocess.Popen(cheat_location)
            # subprocess.Popen(cheat_location, startupinfo=startupinfo, creationflags=subprocess.CREATE_NEW_CONSOLE)
            return redirect('/')
        else:
            subprocess.Popen(f"{cheat_location}+ &")
            return redirect('/')

    @app.route("/exit")
    def exitapp():
        window.destroy()
        print('Closed by User!')
        return ''

    if __name__ == "__main__":
        #app.run(debug=True)
        webview.start()

else:
    # Re-run the program with admin rights
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)